## Updating the libraries

### ffmpeg

Current version: 0.31.5

Updating: Download prebuilt libraries from https://github.com/iteufel/nwjs-ffmpeg-prebuilt/releases.
